<?php
//  Set Entries here to be excluded from the insert.
$exclude = array("035","0359","010a","040a","040b","040c","040d","0970","097b", "097a",);
array_push($exclude, "906a","906b","906c","906d","906e","906f","906g","955a");

?>
