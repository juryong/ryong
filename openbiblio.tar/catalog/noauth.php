<?php
/* This file is part of a copyrighted work; it is distributed with NO WARRANTY.
 * See the file COPYRIGHT.html for more details.
 */
 
  require_once("../shared/common.php");
  $tab = "cataloging";
  $nav = "";

  include("../shared/header.php");

?>

You are not authorized to use the Cataloging tab.

<?php include("../shared/footer.php"); ?>
