insert into %prfx%settings
values (
  'Your Library Name'
  ,'../images/sampleLogo.png'
  ,'N'
  ,'M-F 8am-9pm, Sa noon-5pm, Su 1-5pm'
  ,'111-222-3333'
  ,null
  ,'../opac/index.php'
  ,20
  ,10
  ,'0.7.0'
  ,1
  ,6
  ,'Y'
  ,14
  ,'en'
  ,'iso-8859-1'
  ,null
)
;
