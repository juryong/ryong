insert into %prfx%material_type_dm values (1,'audio tapes','N','tape.gif');
insert into %prfx%material_type_dm values (2,'book','Y','book.gif');
insert into %prfx%material_type_dm values (3,'cd audio','N','cd.gif');
insert into %prfx%material_type_dm values (4,'cd computer','N','cd.gif');
insert into %prfx%material_type_dm values (5,'equipment','N','case.gif');
insert into %prfx%material_type_dm values (6,'magazines','N','mag.gif');
insert into %prfx%material_type_dm values (7,'maps','N','map.gif');
insert into %prfx%material_type_dm values (8,'video/dvd','N','camera.gif');

