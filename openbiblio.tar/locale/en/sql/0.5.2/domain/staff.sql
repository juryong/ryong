insert into %prfx%staff
values (null
  ,sysdate()
  ,sysdate()
  ,1
  ,'admin'
  ,md5('admin')
  ,'Root Administrator'
  ,null
  ,'N'
  ,'Y'
  ,'Y'
  ,'Y'
  ,'Y'
  ,'Y'
)
;
