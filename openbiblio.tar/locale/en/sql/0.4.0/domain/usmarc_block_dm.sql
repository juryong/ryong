insert into %prfx%usmarc_block_dm values (0,'Control information, numbers, and codes');
insert into %prfx%usmarc_block_dm values (1,'Main entry');
insert into %prfx%usmarc_block_dm values (2,'Titles and title paragraph (title, edition, imprint)');
insert into %prfx%usmarc_block_dm values (3,'Physical description, etc.');
insert into %prfx%usmarc_block_dm values (4,'Series statements');
insert into %prfx%usmarc_block_dm values (5,'Notes');
insert into %prfx%usmarc_block_dm values (6,'Subject access fields');
insert into %prfx%usmarc_block_dm values (7,'Added entries other than subject or series, linking fields');
insert into %prfx%usmarc_block_dm values (8,'Series added entries: location, and alternate graphics');
insert into %prfx%usmarc_block_dm values (9,'Reserved for local implementation');

