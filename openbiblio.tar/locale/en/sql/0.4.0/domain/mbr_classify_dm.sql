insert into %prfx%mbr_classify_dm values ('a','adult','Y');
insert into %prfx%mbr_classify_dm values ('j','juvenile','N');
